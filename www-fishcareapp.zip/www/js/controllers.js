angular.module('starter.controllers', [])


.controller('AppCtrl', function($scope, $ionicModal, $timeout, $http, $ionicPopup) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});


  $http({
  method: 'GET',
  url: 'http://192.168.43.244/script_last.php'     // reupère adresse IP de la raspberry --> il faut que la raspberry soit connectée au même serveur que notre mobile 
  }).then(function successCallback(response) {
    // this callback will be called asynchronously
    // when the response is available
  $scope.tempObject = response.data.Temperature; // on recupère la température de la base de donnée 
  console.log(response.data.ph); // afficher sur la console pour verifier que la valeur est bien récupérée 

  // On affiche le poisson bleu quand la température est trop froide 
  $scope.Obj = response.data.ph;
  if($scope.tempObject<=10){
    $scope.poisson="blue";
  }

// Rouge si elle est trop chaude 
  else if($scope.tempObject>35 ){
    $scope.poisson="Red";
  }

// Poisson malade si le ph n'est pas dans la gamme de valeurs autorisé
  else if($scope.Obj<=7 && $scope.Obj>=8){
    $scope.poisson="Sick";
  }
// si tout va bien le poisson est jaune 
  else{
    $scope.poisson="Yellow";
  };

  // une fenetre popup apparait lorsque le poisson ne va pas bien pour indiquer ce qu'il faut faire 

  if($scope.poisson=="blue"){
   $scope.showAlert = function() {
   var alertPopup = $ionicPopup.alert({
     title: 'J\'ai froid',
     template: 'Mon eau est trop froide c\'est dangereux pour moi !'
   })
 }
};

   if($scope.poisson=="Red"){
   $scope.showAlert = function() {
   var alertPopup = $ionicPopup.alert({
     title: 'J\'ai Chaud',
     template: 'Mon eau est trop chaude c\'est dangereux pour moi !'
   })
 }
};

   if($scope.poisson=="Sick"){
   $scope.showAlert = function() {
   var alertPopup = $ionicPopup.alert({
     title: 'Je suis en danger',
     template: 'Change vite mon eau'
   })
 }
};


 // affiche console de verification 
  console.log("Temp Object in successCallback ", $scope.tempObject);
  }, function errorCallback(response) {
    // called asynchronously if an error occurs
    // or server returns response with an error status.
  });
    

// CODE POUR LA CONNEXION UTILISATEURS 

  // Form data for the login modal
  $scope.loginData = {};

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);

    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  };
})



//*********************************************FISHOPEDIA*****************************************************//


// déclaration de plusierus pages pour l'affichage de plusieurs pages 

.controller('PedieCtrl', function($scope) {
  $scope.pedie = [
    { title: 'Le Poisson Rouge', id: 1 },
    { title: 'Le Guppy', id: 2 },
    { title: 'Le Combattant', id: 3 }
  ];
})

.controller('PediesCtrl', function($scope, $stateParams) {
})




/*************************************JEU ************************/
.controller('GameCtrl', function($scope, game) {
  $scope.game = game;
})

.factory('game', function() {
  var tileNames = ['guppy', 'clown', 'baked-potato', 'dinosaur', 'rocket', 'skinny-unicorn',
    'that-guy', 'zeppelin'];

  return new Game(tileNames);
})



//usages:
//- in the repeater as: <mg-card tile="tile"></mg-card>
//- card currently being matched as: <mg-card tile="game.firstPick"></mg-card>

.directive('mgCard', function() {
  return {
    restrict: 'E',
    // instead of inlining the template string here, one could use templateUrl: 'mg-card.html'
    // and then either create a mg-card.html file with the content or add
    // <script type="text/ng-template" id="mg-card.html">.. template here.. </script> element to
    // index.html
    template: '<div class="container">' +
                '<div class="card" ng-class="{flipped: tile.flipped}">' +
                  '<img class="front" ng-src="img/back.png">' +
                  '<img class="back" ng-src="img/{{tile.title}}.png">' +
                '</div>' +
              '</div>',
    scope: {
      tile: '='
    }
  }
});



/****************************************GRAPH***************************/
angular.module('myApp', ['chartjs-directive'])


  .controller('myController', function($scope){

    var data = {
      labels : ["January","February","March","April","May","June","July"],
      datasets : [
        {
          fillColor : "rgba(220,220,220,0.5)",
          strokeColor : "rgba(220,220,220,1)",
          pointColor : "rgba(220,220,220,1)",
          pointStrokeColor : "#fff",
          data : [65,59,90,81,56,55,40]
        },
        {
          fillColor : "rgba(151,187,205,0.5)",
          strokeColor : "rgba(151,187,205,1)",
          pointColor : "rgba(151,187,205,1)",
          pointStrokeColor : "#fff",
          data : [28,48,40,19,96,27,100]
        }
      ]
    }

    $scope.myChart = data;
  });


